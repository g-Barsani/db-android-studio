package br.edu.fatec.bancodedados;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import br.edu.fatec.bancodedados.dao.AlunoDAO;
import br.edu.fatec.bancodedados.model.Aluno;

public class TelaNovo extends AppCompatActivity {

    private EditText edtId;
    private EditText edtNome;
    private EditText edtCpf;
    private EditText edtTelefone;
    private EditText edtListar;
    private AlunoDAO dao;
    private List<Aluno> alunos;
    private Aluno aluno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_novo);
    }

    public void salvar(View view){
        // pegar os dados da tela
        aluno = new Aluno();
        aluno.setNome(edtNome.getText().toString());
        aluno.setCpf(edtCpf.getText().toString());
        aluno.setTelefone(edtTelefone.getText().toString());
        // abrir o BD
        dao = new AlunoDAO(this);
        // Salvar
        long id = dao.insert(aluno);
        Toast.makeText(getApplicationContext(),
                "Aluno inserido com o ID "+id, Toast.LENGTH_LONG).show();
    }

    public void voltar(View view) {
        startActivity(new Intent(this, TelaNovoSair.class));
    }
}